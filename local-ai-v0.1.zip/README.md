# Local AI 🤖📱

Chat de IA **100% offline** no Android, com inferencia local via [llama.cpp](https://github.com/ggml-org/llama.cpp).
Sem permissao de INTERNET — seus dados nunca saem do aparelho.

## Stack

| Camada | Tecnologia |
|---|---|
| UI | Jetpack Compose + Material 3 (Material You) |
| Arquitetura | MVVM + Clean Architecture + Hilt (DI) |
| Persistencia | Room (historico do chat) |
| Inferencia | llama.cpp via JNI (CPU, streaming de tokens) |
| CI | GitHub Actions (NDK + CMake + APK) |

## Estrutura

```
app/src/main/
├── cpp/
│   ├── CMakeLists.txt        # build nativo: ggml + llama + JNI
│   └── llama-jni.cpp         # ponte JNI (load/generate/cancel)
├── java/dev/localai/chat/
│   ├── MainActivity.kt
│   ├── llm/                  # LlamaBridge (JNI), InferenceEngine, estados
│   ├── data/                 # Room: entities, dao, repository
│   ├── di/                   # modulo Hilt
│   └── ui/
│       ├── theme/            # Material 3 (dynamic color)
│       └── chat/             # ChatScreen, ViewModel, componentes
└── res/
```

O llama.cpp **nao fica no repositorio**: o workflow do GitHub Actions clona a tag
pinada (`v0.3.0`) em `app/src/main/cpp/llama.cpp` antes do build (ver `.github/workflows/build.yml`).

## Build local

Requisitos: JDK 17, Android Studio com SDK 35 + NDK 27.

```bash
# 1. baixar as fontes do llama.cpp na versao pinada
git clone --depth 1 --branch v0.3.0 https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp

# 2. abrir no Android Studio e rodar, ou:
gradle :app:assembleDebug
```

## Build no GitHub (CI)

Todo push em `main` roda o workflow:
1. Instala JDK 17 + Android SDK + NDK 27 + CMake
2. Clona o llama.cpp (tag pinada, com fallback pra master)
3. Compila as libs nativas (arm64-v8a, armeabi-v7a, x86_64) via CMake
4. Gera o APK de release e sobe como artifact

## Como usar

1. Baixe um modelo **.gguf** pequeno (ex.: Qwen2.5-0.5B-Instruct, TinyLlama) no aparelho
2. Abra o app → toque no chip "Sem modelo" → selecione o .gguf
3. Espere carregar e converse. Streaming de tokens em tempo real, botao de parar.

## Roadmap

- [ ] Templates de chat por modelo (ChatML, Llama-3, Gemma…)
- [ ] Download de modelos via Hugging Face dentro do app
- [ ] Backend Vulkan (GPU) no llama.cpp
- [ ] Multi-conversa + renomear/apagar chats
- [ ] Ajuste de temperatura/top-k/top-p na UI
- [ ] Exportar conversa

## Notas de robustez

- **Cancelamento cooperativo**: cancelar o Flow de geracao sinaliza o loop nativo e persiste o texto parcial
- **Threading**: inferencia sempre em `Dispatchers.IO`; UI nunca bloqueada
- **JNI defensivo**: checagem de null em modelo/contexto, tratamento de falha de tokenizacao
- **ProGuard**: metodos nativos preservados (`-keepclassmembers ... native <methods>`)
