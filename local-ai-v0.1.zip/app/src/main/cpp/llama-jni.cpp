// Ponte JNI entre Kotlin (dev.localai.chat.llm.LlamaBridge) e o llama.cpp.
// API C publica: include/llama.h (tag v0.3.0).
#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <string>
#include <vector>
#include <atomic>
#include <mutex>

#include "llama.h"

#define LOG_TAG "LocalAI-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

llama_model*    g_model     = nullptr;
llama_context*  g_ctx       = nullptr;
const llama_vocab* g_vocab  = nullptr;
std::atomic<bool> g_cancelled{false};
std::mutex g_model_mutex;

void free_model() {
    if (g_ctx)    { llama_free(g_ctx);    g_ctx    = nullptr; }
    if (g_model)  { llama_free_model(g_model); g_model = nullptr; }
    g_vocab = nullptr;
}

std::string token_to_piece(const llama_vocab* vocab, llama_token token) {
    std::string piece(64, '\0');
    int n = llama_token_to_piece(vocab, token, piece.data(), (int) piece.size(), 0, true);
    if (n < 0) {
        piece.resize((size_t) -n);
        n = llama_token_to_piece(vocab, token, piece.data(), (int) piece.size(), 0, true);
    }
    piece.resize(n < 0 ? 0 : (size_t) n);
    return piece;
}

} // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM*, void*) {
    llama_backend_init();
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_dev_localai_chat_llm_LlamaBridge_loadModel(JNIEnv* env, jclass, jstring path) {
    std::lock_guard<std::mutex> lock(g_model_mutex);
    g_cancelled.store(true);
    if (g_model) free_model();

    const char* c_path = env->GetStringUTFChars(path, nullptr);
    LOGI("carregando modelo: %s", c_path);

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = 0; // CPU-only no Android (v1). Vulkan fica pro roadmap.

    g_model = llama_load_model_from_file(c_path, mparams);
    env->ReleaseStringUTFChars(path, c_path);

    if (!g_model) {
        LOGE("falha ao carregar modelo");
        return JNI_FALSE;
    }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx   = 4096;
    cparams.n_batch = 2048;
    g_ctx = llama_init_from_model(g_model, cparams);
    if (!g_ctx) {
        LOGE("falha ao criar contexto");
        free_model();
        return JNI_FALSE;
    }

    g_vocab = llama_model_get_vocab(g_model);
    LOGI("modelo carregado");
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_dev_localai_chat_llm_LlamaBridge_unloadModel(JNIEnv*, jclass) {
    // Request cancellation before waiting for the inference lock. The active
    // generation observes the flag and exits before native resources are freed.
    g_cancelled.store(true);
    std::lock_guard<std::mutex> lock(g_model_mutex);
    free_model();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_dev_localai_chat_llm_LlamaBridge_isModelLoaded(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(g_model_mutex);
    return g_model != nullptr ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_dev_localai_chat_llm_LlamaBridge_cancelGeneration(JNIEnv*, jclass) {
    g_cancelled.store(true);
    LOGI("cancelamento solicitado");
}

extern "C" JNIEXPORT jstring JNICALL
Java_dev_localai_chat_llm_LlamaBridge_generate(
        JNIEnv* env, jclass, jstring jprompt, jobject jcallback) {

    std::lock_guard<std::mutex> lock(g_model_mutex);
    if (!g_model || !g_ctx || !g_vocab) {
        return env->NewStringUTF("");
    }

    g_cancelled.store(false);
    jobject callback = env->NewGlobalRef(jcallback);
    jclass callbackClass = env->GetObjectClass(callback);
    jmethodID onToken = env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;)V");

    const char* c_prompt = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(c_prompt);
    env->ReleaseStringUTFChars(jprompt, c_prompt);

    auto emit = [&](const std::string& piece) {
        if (g_cancelled.load() || piece.empty()) return;
        jstring s = env->NewStringUTF(piece.c_str());
        env->CallVoidMethod(callback, onToken, s);
        env->DeleteLocalRef(s);
        // Verifica se a JVM lançou exceção (ex.: thread interrompida)
        if (env->ExceptionCheck()) {
            env->ExceptionClear();
            g_cancelled.store(true);
        }
    };

    const int n_ctx = llama_n_ctx(g_ctx);
    const int n_batch = 2048;

    // tokeniza o prompt
    std::vector<llama_token> prompt_tokens(prompt.size() + 8);
    int n_tokens = llama_tokenize(
        g_vocab, prompt.c_str(), (int) prompt.size(),
        prompt_tokens.data(), (int) prompt_tokens.size(), true, false);
    if (n_tokens < 0) {
        LOGE("falha ao tokenizar prompt (%d)", n_tokens);
        env->DeleteGlobalRef(callback);
        return env->NewStringUTF("");
    }
    prompt_tokens.resize((size_t) n_tokens);

    // Each request sends the complete chat history. Clear the previous KV
    // cache so the native context matches the prompt being evaluated now.
    llama_kv_cache_seq_rm(g_ctx, -1, 0, -1);

    // sampler: top-k + top-p + temperatura
    llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    // alimenta o prompt em blocos (respeitando cancelamento)
    bool failed = false;
    for (int i = 0; i < n_tokens && !g_cancelled.load(); i += n_batch) {
        int chunk = std::min(n_batch, n_tokens - i);
        llama_batch batch = llama_batch_get_one(prompt_tokens.data() + i, chunk);
        if (llama_decode(g_ctx, batch) != 0) { failed = true; break; }
    }

    std::string result;
    const llama_token eos = llama_vocab_eos(g_vocab);
    llama_token new_token = -1;

    if (!failed && !g_cancelled.load()) {
        new_token = llama_sampler_sample(smpl, g_ctx, -1);
        llama_sampler_accept(smpl, new_token);
        if (new_token != eos) {
            std::string piece = token_to_piece(g_vocab, new_token);
            result += piece;
            emit(piece);
        }
    }

    int n_generated = 0;
    while (new_token != eos && !g_cancelled.load() && !failed
           && n_generated + n_tokens < n_ctx) {
        llama_batch batch = llama_batch_get_one(&new_token, 1);
        if (llama_decode(g_ctx, batch) != 0) { failed = true; break; }

        new_token = llama_sampler_sample(smpl, g_ctx, -1);
        llama_sampler_accept(smpl, new_token);
        if (new_token == eos) break;

        std::string piece = token_to_piece(g_vocab, new_token);
        result += piece;
        emit(piece);
        n_generated++;
    }

    llama_sampler_free(smpl);
    env->DeleteGlobalRef(callback);
    LOGI("geracao finalizada: %d tokens%s", n_generated, g_cancelled.load() ? " (cancelada)" : "");
    return env->NewStringUTF(result.c_str());
}
