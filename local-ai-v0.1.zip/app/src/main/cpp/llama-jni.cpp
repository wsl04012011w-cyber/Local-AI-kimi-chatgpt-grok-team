// Ponte JNI entre Kotlin (dev.localai.chat.llm.LlamaBridge) e o llama.cpp.
// API C publica: include/llama.h da tag pinada pelo workflow (v0.3.0).
//
// Mudancas em relacao a v0.1/v0.2 (ver CORRECOES.md):
//  - strings Java <-> C++ via UTF-16 (NewString/GetStringChars) em vez de NewStringUTF:
//    pedacos de token com UTF-8 incompleto / 4 bytes derrubavam a VM (CheckJNI) ou geravam lixo;
//  - parada por llama_vocab_is_eog (fim de turno de Gemma/Qwen), nao so EOS;
//  - prompt tokenizado com parse_special=true (marcadores do template viram tokens de verdade);
//  - chat template embutido no GGUF exposto ao Kotlin (applyChatTemplate / chatTemplate);
//  - erros nativos viram RuntimeException com etapa + codigo, em vez de string vazia;
//  - instrumentacao por etapa SEM registrar conteudo de prompt/resposta;
//  - APIs depreciadas trocadas (llama_kv_cache_seq_rm, llama_load_model_from_file, llama_free_model).
#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <exception>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"
#include "utf8_stream.h"

#define LOG_TAG "LocalAI-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

constexpr int kBatch = 512;      // n_batch == n_ubatch: limita o buffer de logits (vocab grande do Qwen)
constexpr int kCtx = 4096;
constexpr int kMinGenRoom = 32;  // minimo de espaco no contexto para gerar algo

llama_model*       g_model = nullptr;
llama_context*     g_ctx   = nullptr;
const llama_vocab* g_vocab = nullptr;
std::atomic<bool>  g_cancelled{false};
std::atomic<bool>  g_loaded{false};   // permite isModelLoaded sem segurar o mutex da geracao
std::mutex         g_model_mutex;

void free_model() {
    g_loaded.store(false);
    if (g_ctx)   { llama_free(g_ctx);        g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    g_vocab = nullptr;
}

std::string token_to_piece(const llama_vocab* vocab, llama_token token) {
    std::string piece(64, '\0');
    int n = llama_token_to_piece(vocab, token, piece.data(), (int) piece.size(), 0, true);
    if (n < 0) {
        piece.resize((size_t) -n);
        n = llama_token_to_piece(vocab, token, piece.data(), (int) piece.size(), 0, true);
    }
    piece.resize(n < 0 ? 0 : (size_t) n);
    return piece;
}

std::string jstring_to_utf8(JNIEnv* env, jstring s) {
    if (!s) return {};
    const jchar* chars = env->GetStringChars(s, nullptr);
    if (!chars) return {};
    std::string out = localai::utf16_to_utf8(reinterpret_cast<const char16_t*>(chars),
                                             (size_t) env->GetStringLength(s));
    env->ReleaseStringChars(s, chars);
    return out;
}

jstring u16_to_jstring(JNIEnv* env, const std::u16string& s) {
    return env->NewString(reinterpret_cast<const jchar*>(s.data()), (jsize) s.size());
}

jstring utf8_to_jstring(JNIEnv* env, const std::string& s) {
    localai::Utf8Stream st;
    std::u16string u = st.push(s) + st.finish();
    return u16_to_jstring(env, u);
}

void throw_runtime(JNIEnv* env, const std::string& msg) {
    if (env->ExceptionCheck()) return;  // ja ha uma excecao pendente
    jclass cls = env->FindClass("java/lang/RuntimeException");
    if (cls) { env->ThrowNew(cls, msg.c_str()); env->DeleteLocalRef(cls); }
}

// Libera sampler e referencia global em qualquer saida (inclusive excecao C++).
struct GenGuard {
    JNIEnv* env;
    jobject callback = nullptr;
    llama_sampler* smpl = nullptr;
    ~GenGuard() {
        if (smpl) llama_sampler_free(smpl);
        if (callback) env->DeleteGlobalRef(callback);
    }
};

} // namespace

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM*, void*) {
    llama_backend_init();
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_dev_localai_chat_llm_LlamaBridge_loadModel(JNIEnv* env, jobject, jstring path) {
    // Sinaliza ANTES de esperar o mutex: uma geracao em andamento precisa ver o cancelamento.
    g_cancelled.store(true);
    std::lock_guard<std::mutex> lock(g_model_mutex);
    if (g_model) free_model();

    const std::string c_path = jstring_to_utf8(env, path);
    LOGI("stage=load_model begin");

    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = 0; // CPU-only no Android (v1). Vulkan fica pro roadmap.

    g_model = llama_model_load_from_file(c_path.c_str(), mparams);
    if (!g_model) {
        LOGE("stage=load_model falhou ao carregar o arquivo");
        return JNI_FALSE;
    }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx    = kCtx;
    cparams.n_batch  = kBatch;
    cparams.n_ubatch = kBatch;
    g_ctx = llama_init_from_model(g_model, cparams);
    if (!g_ctx) {
        LOGE("stage=load_context falhou (memoria insuficiente ou parametros invalidos)");
        free_model();
        return JNI_FALSE;
    }

    g_vocab = llama_model_get_vocab(g_model);
    g_loaded.store(true);
    LOGI("stage=load_model ok n_ctx=%d n_batch=%d", (int) llama_n_ctx(g_ctx), kBatch);
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_dev_localai_chat_llm_LlamaBridge_unloadModel(JNIEnv*, jobject) {
    // Pede cancelamento antes de esperar o lock: a geracao ativa sai antes de liberar os recursos.
    g_cancelled.store(true);
    std::lock_guard<std::mutex> lock(g_model_mutex);
    free_model();
}

extern "C" JNIEXPORT jboolean JNICALL
Java_dev_localai_chat_llm_LlamaBridge_isModelLoaded(JNIEnv*, jobject) {
    return g_loaded.load() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_dev_localai_chat_llm_LlamaBridge_cancelGeneration(JNIEnv*, jobject) {
    g_cancelled.store(true);
    LOGI("cancelamento solicitado");
}

// Texto do chat template embutido no GGUF ("" se nao houver).
extern "C" JNIEXPORT jstring JNICALL
Java_dev_localai_chat_llm_LlamaBridge_chatTemplate(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> lock(g_model_mutex);
    const char* tmpl = g_model ? llama_model_chat_template(g_model, nullptr) : nullptr;
    return utf8_to_jstring(env, tmpl ? tmpl : "");
}

// Aplica o template embutido no GGUF via llama_chat_apply_template (so reconhece os formatos
// que o llama.cpp conhece). Retorna null se nao houver template ou se ele nao for suportado;
// o Kotlin entao escolhe um template por familia.
extern "C" JNIEXPORT jstring JNICALL
Java_dev_localai_chat_llm_LlamaBridge_applyChatTemplate(
        JNIEnv* env, jobject, jobjectArray jroles, jobjectArray jcontents) {
    std::lock_guard<std::mutex> lock(g_model_mutex);
    if (!g_model || !jroles || !jcontents) return nullptr;
    const char* tmpl = llama_model_chat_template(g_model, nullptr);
    if (!tmpl) return nullptr;

    const jsize n = env->GetArrayLength(jroles);
    if (n <= 0 || n != env->GetArrayLength(jcontents)) return nullptr;

    std::vector<std::string> roles((size_t) n), contents((size_t) n);
    size_t total = 0;
    for (jsize i = 0; i < n; i++) {
        jstring r = (jstring) env->GetObjectArrayElement(jroles, i);
        jstring c = (jstring) env->GetObjectArrayElement(jcontents, i);
        roles[(size_t) i]    = jstring_to_utf8(env, r);
        contents[(size_t) i] = jstring_to_utf8(env, c);
        total += roles[(size_t) i].size() + contents[(size_t) i].size();
        if (r) env->DeleteLocalRef(r);
        if (c) env->DeleteLocalRef(c);
    }
    std::vector<llama_chat_message> msgs((size_t) n);
    for (size_t i = 0; i < (size_t) n; i++) {
        msgs[i].role    = roles[i].c_str();
        msgs[i].content = contents[i].c_str();
    }

    try {
        std::string buf(total * 2 + 1024, '\0');
        int32_t len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true,
                                                buf.data(), (int32_t) buf.size());
        if (len > (int32_t) buf.size()) {
            buf.assign((size_t) len, '\0');
            len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true,
                                            buf.data(), (int32_t) buf.size());
        }
        if (len < 0) {
            LOGI("stage=apply_template template embutido nao suportado (rc=%d)", (int) len);
            return nullptr;
        }
        buf.resize((size_t) len);
        return utf8_to_jstring(env, buf);
    } catch (const std::exception& e) {
        LOGE("stage=apply_template excecao C++: %s", e.what());
        return nullptr;
    }
}

// true se [text] vira exatamente 1 token quando marcadores especiais sao interpretados.
// Usado para identificar a familia de template (ex.: "<start_of_turn>", "<|im_start|>").
extern "C" JNIEXPORT jboolean JNICALL
Java_dev_localai_chat_llm_LlamaBridge_isSingleSpecialToken(JNIEnv* env, jobject, jstring jtext) {
    std::lock_guard<std::mutex> lock(g_model_mutex);
    if (!g_vocab) return JNI_FALSE;
    const std::string text = jstring_to_utf8(env, jtext);
    llama_token toks[4];
    const int n = llama_tokenize(g_vocab, text.c_str(), (int) text.size(), toks, 4, false, true);
    return n == 1 ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_dev_localai_chat_llm_LlamaBridge_generate(
        JNIEnv* env, jobject, jstring jprompt, jobject jcallback) {

    std::lock_guard<std::mutex> lock(g_model_mutex);
    if (!g_model || !g_ctx || !g_vocab) {
        throw_runtime(env, "etapa=generate erro=modelo_nao_carregado");
        return nullptr;
    }
    g_cancelled.store(false);

    GenGuard guard{env};
    std::string error;                       // preenchido em qualquer falha
    std::u16string result;                   // texto final (UTF-16)
    int n_generated = 0;
    const char* stop_reason = "desconhecido";

    try {
        guard.callback = env->NewGlobalRef(jcallback);
        if (!guard.callback) {
            throw_runtime(env, "etapa=callback erro=NewGlobalRef_falhou");
            return nullptr;
        }
        jclass callbackClass = env->GetObjectClass(guard.callback);
        jmethodID onToken = callbackClass
            ? env->GetMethodID(callbackClass, "onToken", "(Ljava/lang/String;)V") : nullptr;
        if (callbackClass) env->DeleteLocalRef(callbackClass);
        if (!onToken) {
            env->ExceptionClear();
            throw_runtime(env, "etapa=callback erro=metodo_onToken_nao_encontrado");
            return nullptr;
        }

        localai::Utf8Stream utf8;
        auto emit_u16 = [&](const std::u16string& u) {
            if (u.empty()) return;
            result += u;
            if (g_cancelled.load()) return;
            jstring s = u16_to_jstring(env, u);
            if (!s) { g_cancelled.store(true); return; }          // OutOfMemoryError pendente
            env->CallVoidMethod(guard.callback, onToken, s);
            env->DeleteLocalRef(s);
            if (env->ExceptionCheck()) {                          // excecao Kotlin no callback
                env->ExceptionClear();
                g_cancelled.store(true);
            }
        };

        const int n_ctx = (int) llama_n_ctx(g_ctx);
        const std::string prompt = jstring_to_utf8(env, jprompt);

        // O template ja inclui o BOS quando precisa; evita BOS duplicado.
        const bool has_leading_bos = prompt.rfind("<bos>", 0) == 0
                                  || prompt.rfind("<s>", 0) == 0
                                  || prompt.rfind("<|begin_of_text|>", 0) == 0;

        // --- tokenizacao (parse_special=true: marcadores do template viram tokens de controle)
        std::vector<llama_token> tokens(prompt.size() + 8);
        int n_tokens = llama_tokenize(g_vocab, prompt.c_str(), (int) prompt.size(),
                                      tokens.data(), (int) tokens.size(),
                                      /*add_special=*/!has_leading_bos, /*parse_special=*/true);
        if (n_tokens < 0) {   // buffer pequeno: o retorno negativo e -(tamanho necessario)
            tokens.resize((size_t) -n_tokens);
            n_tokens = llama_tokenize(g_vocab, prompt.c_str(), (int) prompt.size(),
                                      tokens.data(), (int) tokens.size(),
                                      !has_leading_bos, true);
        }
        if (n_tokens <= 0) {
            error = "etapa=tokenize codigo=" + std::to_string(n_tokens);
            throw_runtime(env, error);
            LOGE("%s", error.c_str());
            return nullptr;
        }
        tokens.resize((size_t) n_tokens);
        LOGI("stage=tokenize ok n_tokens=%d n_ctx=%d prompt_bytes=%zu", n_tokens, n_ctx, prompt.size());

        if (n_tokens + kMinGenRoom > n_ctx) {
            error = "etapa=prompt erro=prompt_muito_longo n_tokens=" + std::to_string(n_tokens)
                  + " n_ctx=" + std::to_string(n_ctx);
            throw_runtime(env, error);
            LOGE("%s", error.c_str());
            return nullptr;
        }

        // O historico completo e reenviado a cada pedido: zera o KV cache para o contexto nativo
        // refletir exatamente o prompt atual (llama_memory_clear substitui llama_kv_cache_seq_rm).
        llama_memory_clear(llama_get_memory(g_ctx), true);

        guard.smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
        llama_sampler_chain_add(guard.smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(guard.smpl, llama_sampler_init_top_p(0.9f, 1));
        llama_sampler_chain_add(guard.smpl, llama_sampler_init_temp(0.7f));
        llama_sampler_chain_add(guard.smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

        // --- decodifica o prompt em blocos (respeitando cancelamento)
        for (int i = 0; i < n_tokens && !g_cancelled.load(); i += kBatch) {
            const int chunk = std::min(kBatch, n_tokens - i);
            llama_batch batch = llama_batch_get_one(tokens.data() + i, chunk);
            const int rc = llama_decode(g_ctx, batch);
            if (rc != 0) {
                error = "etapa=prompt_decode codigo=" + std::to_string(rc)
                      + " offset=" + std::to_string(i) + " n_tokens=" + std::to_string(n_tokens);
                break;
            }
        }
        if (error.empty()) LOGI("stage=prompt_decode ok%s", g_cancelled.load() ? " (cancelado)" : "");

        // --- laco de geracao
        stop_reason = "cancelado";
        llama_token new_token = 0;
        while (error.empty() && !g_cancelled.load()) {
            if (n_tokens + n_generated >= n_ctx) { stop_reason = "contexto_cheio"; break; }

            new_token = llama_sampler_sample(guard.smpl, g_ctx, -1);
            if (llama_vocab_is_eog(g_vocab, new_token)) {         // <end_of_turn>, <|im_end|>, EOS...
                stop_reason = "eog";
                break;
            }
            llama_sampler_accept(guard.smpl, new_token);

            const std::string piece = token_to_piece(g_vocab, new_token);
            emit_u16(utf8.push(piece));
            n_generated++;

            llama_batch batch = llama_batch_get_one(&new_token, 1);
            const int rc = llama_decode(g_ctx, batch);
            if (rc != 0) {
                error = "etapa=decode codigo=" + std::to_string(rc)
                      + " n_gerados=" + std::to_string(n_generated);
                break;
            }
        }
        emit_u16(utf8.finish());   // bytes de UTF-8 truncado no fim viram U+FFFD

        LOGI("stage=done n_gerados=%d parada=%s", n_generated, error.empty() ? stop_reason : "erro");
        if (!error.empty()) {
            LOGE("%s", error.c_str());
            throw_runtime(env, error);
            return nullptr;
        }
        return u16_to_jstring(env, result);

    } catch (const std::exception& e) {
        error = std::string("etapa=generate excecao_cpp=") + e.what();
    } catch (...) {
        error = "etapa=generate excecao_cpp=desconhecida";
    }
    LOGE("%s", error.c_str());
    throw_runtime(env, error);
    return nullptr;
}
