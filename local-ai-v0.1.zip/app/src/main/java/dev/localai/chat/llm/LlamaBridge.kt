package dev.localai.chat.llm

/**
 * Ponte JNI para o llama.cpp compilado como libllama-jni.so.
 * Os simbolos nativos sao implementados em cpp/llama-jni.cpp.
 */
object LlamaBridge {

    init {
        System.loadLibrary("llama-jni")
    }

    /** Carrega um modelo .gguf. Retorna true em sucesso. */
    external fun loadModel(path: String): Boolean

    /** Libera modelo + contexto da memoria. */
    external fun unloadModel()

    external fun isModelLoaded(): Boolean

    /**
     * Roda inferencia com streaming. Bloqueia a thread chamadora;
     * chame de um dispatcher de IO. O callback recebe cada pedaco
     * de texto gerado. Retorna o texto completo no final.
     */
    external fun generate(prompt: String, callback: TokenCallback): String

    /** Sinaliza cancelamento para o loop de geracao nativo. */
    external fun cancelGeneration()

    fun interface TokenCallback {
        fun onToken(token: String)
    }
}
