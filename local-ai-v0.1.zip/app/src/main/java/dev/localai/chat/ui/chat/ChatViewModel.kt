package dev.localai.chat.ui.chat

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dev.localai.chat.data.ChatRepository
import dev.localai.chat.data.db.MessageEntity
import dev.localai.chat.llm.ImportState
import dev.localai.chat.llm.InferenceEngine
import dev.localai.chat.llm.ModelState
import java.io.File
import java.io.IOException
import javax.inject.Inject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Role { USER, ASSISTANT }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val content: String,
    val isStreaming: Boolean = false,
)

private const val CHAT_TEMPLATE_SYSTEM = "<|im_start|>system\nVoce e um assistente util e conciso. Responda no idioma do usuario.<|im_end|>\n"
private const val CHAT_TEMPLATE_PREFIX = "<|im_start|>%s\n%s<|im_end|>\n"

@HiltViewModel
class ChatViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val engine: InferenceEngine,
    private val repository: ChatRepository,
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    val modelState: StateFlow<ModelState> = engine.modelState

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _importState = MutableStateFlow<ImportState>(ImportState.Idle)
    val importState: StateFlow<ImportState> = _importState.asStateFlow()

    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    private var generationJob: Job? = null

    init {
        viewModelScope.launch {
            repository.observeMessages().collect { entities ->
                val streaming = _messages.value.lastOrNull()?.takeIf { it.isStreaming }
                _messages.value = entities.map { entity ->
                    if (streaming != null && entity.id == streaming.id) streaming
                    else entity.toChatMessage()
                }
            }
        }
    }

    fun importModel(uri: Uri) {
        if (_importState.value is ImportState.Importing) return
        viewModelScope.launch {
            _importState.value = ImportState.Importing(uri.lastPathSegment ?: "modelo.gguf")
            try {
                val dest = copyModelToInternalStorage(uri)
                val loaded = engine.loadModel(dest.absolutePath)
                if (!loaded) _events.emit("Nao foi possivel carregar o modelo. Verifique se e um .gguf valido.")
            } catch (e: IOException) {
                _events.emit("Erro ao copiar o modelo: ${e.message}")
            } finally {
                _importState.value = ImportState.Idle
            }
        }
    }

    fun unloadModel() {
        stop()
        engine.unload()
    }

    fun send(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || _isGenerating.value) return
        if (engine.modelState.value !is ModelState.Loaded) {
            viewModelScope.launch { _events.emit("Carregue um modelo primeiro.") }
            return
        }

        viewModelScope.launch {
            val (userId, _) = repository.addMessage(Role.USER, trimmed)
            appendLocal(ChatMessage(userId, Role.USER, trimmed))

            val (assistantId, _) = repository.addMessage(Role.ASSISTANT, "")
            appendLocal(ChatMessage(assistantId, Role.ASSISTANT, "", isStreaming = true))
            _isGenerating.value = true

            val prompt = buildPrompt(trimmed)
            generationJob = viewModelScope.launch {
                val sb = StringBuilder()
                try {
                    engine.generate(prompt).collect { token ->
                        sb.append(token)
                        updateStreaming(assistantId, sb.toString())
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    _events.emit("Erro na inferencia: ${e.message}")
                } finally {
                    repository.updateContent(assistantId, sb.toString())
                    finishStreaming(assistantId, sb.toString())
                    _isGenerating.value = false
                    generationJob = null
                }
            }
        }
    }

    fun stop() {
        generationJob?.cancel()
        generationJob = null
        engine.cancel()
    }

    fun clearChat() {
        stop()
        viewModelScope.launch {
            repository.clear()
            _messages.value = emptyList()
        }
    }

    private fun buildPrompt(userText: String): String {
        val history = _messages.value.filter { !it.isStreaming && it.content.isNotBlank() }.takeLast(12)
        val sb = StringBuilder(CHAT_TEMPLATE_SYSTEM)
        history.dropLast(1).forEach { msg ->
            sb.append(
                CHAT_TEMPLATE_PREFIX.format(
                    if (msg.role == Role.USER) "user" else "assistant",
                    msg.content,
                ),
            )
        }
        sb.append(CHAT_TEMPLATE_FORMAT_USER.format(userText))
        return sb.toString()
    }

    private suspend fun copyModelToInternalStorage(uri: Uri): File =
        withContext(Dispatchers.IO) {
            val dir = File(context.filesDir, "models").apply { mkdirs() }
            val dest = File(dir, "model.gguf")
            context.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            } ?: throw IOException("Nao foi possivel ler o arquivo selecionado")
            dest
        }

    private fun appendLocal(message: ChatMessage) {
        _messages.value = _messages.value + message
    }

    private fun updateStreaming(id: Long, content: String) {
        _messages.value = _messages.value.map {
            if (it.id == id) it.copy(content = content) else it
        }
    }

    private fun finishStreaming(id: Long, content: String) {
        _messages.value = _messages.value.map {
            if (it.id == id) it.copy(content = content, isStreaming = false) else it
        }
    }

    private fun MessageEntity.toChatMessage() = ChatMessage(
        id = id,
        role = if (role == "user") Role.USER else Role.ASSISTANT,
        content = content,
    )

    companion object {
        private const val CHAT_TEMPLATE_FORMAT_USER = "<|im_start|>user\n%s<|im_end|>\n<|im_start|>assistant\n"
    }
}
