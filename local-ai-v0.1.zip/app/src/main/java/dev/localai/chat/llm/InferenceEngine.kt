package dev.localai.chat.llm

import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

/**
 * Fachada thread-safe sobre [LlamaBridge]. Gerencia estado do modelo
 * e expoe geracao como Flow<String> (streaming de tokens).
 */
@Singleton
class InferenceEngine @Inject constructor() {

    private val _modelState = kotlinx.coroutines.flow.MutableStateFlow<ModelState>(ModelState.NotLoaded)
    val modelState: kotlinx.coroutines.flow.StateFlow<ModelState> = _modelState

    suspend fun loadModel(path: String): Boolean = withContext(Dispatchers.IO) {
        if (_modelState.value is ModelState.Loaded) unload()
        _modelState.value = ModelState.Loading
        val ok = runCatching { LlamaBridge.loadModel(path) }.getOrDefault(false)
        _modelState.value = if (ok) {
            ModelState.Loaded(File(path).name)
        } else {
            ModelState.Error("Falha ao carregar o modelo")
        }
        ok
    }

    fun unload() {
        runCatching { LlamaBridge.unloadModel() }
        _modelState.value = ModelState.NotLoaded
    }

    /** Streaming de tokens; cancelar o Flow tambem cancela a geracao nativa. */
    fun generate(prompt: String): Flow<String> = callbackFlow {
        val result = runCatching {
            LlamaBridge.generate(prompt) { token -> trySend(token) }
        }
        result.exceptionOrNull()?.let { close(it) } ?: close()
    }.flowOn(Dispatchers.IO)

    fun cancel() = LlamaBridge.cancelGeneration()
}
