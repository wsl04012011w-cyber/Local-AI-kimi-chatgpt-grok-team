package dev.localai.chat.llm

import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/**
 * Fachada thread-safe sobre [LlamaBridge]. Gerencia estado do modelo
 * e expoe geracao como Flow<String> (streaming de tokens).
 */
@Singleton
class InferenceEngine @Inject constructor() {

    private val _modelState = kotlinx.coroutines.flow.MutableStateFlow<ModelState>(ModelState.NotLoaded)
    val modelState: kotlinx.coroutines.flow.StateFlow<ModelState> = _modelState

    suspend fun loadModel(path: String): Boolean = withContext(Dispatchers.IO) {
        if (_modelState.value is ModelState.Loaded) unload()
        _modelState.value = ModelState.Loading
        val ok = runCatching { LlamaBridge.loadModel(path) }.getOrDefault(false)
        _modelState.value = if (ok) {
            ModelState.Loaded(File(path).name)
        } else {
            ModelState.Error("Falha ao carregar o modelo")
        }
        ok
    }

    fun unload() {
        cancel()
        runCatching { LlamaBridge.unloadModel() }
        _modelState.value = ModelState.NotLoaded
    }

    /**
     * Streaming de tokens. Cancelar o Flow (ou chamar [cancel]) interrompe
     * o loop nativo via flag cooperativa. O texto parcial já emitido é
     * preservado pelo coletor.
     */
    fun generate(prompt: String): Flow<String> = callbackFlow {
        val result = runCatching {
            LlamaBridge.generate(prompt) { token ->
                if (isActive) {
                    trySend(token)
                }
            }
        }
        result.exceptionOrNull()?.let { close(it) } ?: close()

        awaitClose {
            // Garante que o nativo pare mesmo se o coletor for cancelado
            LlamaBridge.cancelGeneration()
        }
    }.flowOn(Dispatchers.IO)

    fun cancel() = LlamaBridge.cancelGeneration()
}
