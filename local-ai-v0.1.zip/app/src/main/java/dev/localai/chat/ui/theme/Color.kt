package dev.localai.chat.ui.theme

import androidx.compose.ui.graphics.Color

// Paleta esmeralda "AI local" — usada quando o usuario desliga o dynamic color
val Emerald80 = Color(0xFF5EEAD4)
val Emerald90 = Color(0xFF99F6E4)
val Emerald30 = Color(0xFF0F766E)
val Emerald10 = Color(0xFF022C2A)

val Slate95 = Color(0xFFF1F5F9)
val Slate20 = Color(0xFF0B1220)
val Slate10 = Color(0xFF070B14)

val Ink90 = Color(0xFFE2E8F0)
val Ink30 = Color(0xFF334155)
