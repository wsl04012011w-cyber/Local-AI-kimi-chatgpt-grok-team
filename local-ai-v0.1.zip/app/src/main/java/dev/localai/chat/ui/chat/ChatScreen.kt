package dev.localai.chat.ui.chat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Eject
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.localai.chat.R
import dev.localai.chat.llm.ImportState
import dev.localai.chat.llm.ModelState
import dev.localai.chat.ui.chat.components.ChatBubble
import dev.localai.chat.ui.chat.components.ChatInputBar
import dev.localai.chat.ui.chat.components.EmptyState
import dev.localai.chat.ui.chat.components.ImportingDialog
import dev.localai.chat.ui.chat.components.ModelStatusChip
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel = hiltViewModel()) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val modelState by viewModel.modelState.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val importState by viewModel.importState.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val modelPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri -> uri?.let(viewModel::importModel) }

    var showMenu by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }

    // Detecta se o usuário está próximo do final da lista
    val isAtBottom by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val total = listState.layoutInfo.totalItemsCount
            total == 0 || lastVisible >= total - 2
        }
    }

    // Mostra FAB de "voltar ao final" quando o usuário rolou para cima
    val showScrollToBottom by remember {
        derivedStateOf {
            messages.isNotEmpty() && !isAtBottom
        }
    }

    LaunchedEffect(Unit) {
        viewModel.events.collect { message -> snackbarHostState.showSnackbar(message) }
    }

    // Scroll inteligente: só acompanha se o usuário estiver no final
    val lastContentLen = messages.lastOrNull()?.content?.length ?: 0
    val lastThinkingLen = messages.lastOrNull()?.thinkingContent?.length ?: 0
    LaunchedEffect(messages.size, lastContentLen, lastThinkingLen, isGenerating) {
        if (messages.isNotEmpty() && isAtBottom) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    ModelStatusChip(
                        state = modelState,
                        onClick = { modelPicker.launch(arrayOf("*/*")) },
                    )
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Opcoes")
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.load_model)) },
                            onClick = {
                                showMenu = false
                                modelPicker.launch(arrayOf("*/*"))
                            },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.unload_model)) },
                            leadingIcon = { Icon(Icons.Filled.Eject, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                viewModel.unloadModel()
                            },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.clear_chat)) },
                            leadingIcon = {
                                Icon(Icons.Filled.DeleteOutline, contentDescription = null)
                            },
                            onClick = {
                                showMenu = false
                                showClearConfirm = true
                            },
                        )
                    }
                },
                // Garante que a TopAppBar respeite a status bar
                windowInsets = TopAppBarDefaults.windowInsets,
            )
        },
        bottomBar = {
            // imePadding + navigationBars para teclado e barra de navegação
            Box(
                modifier = Modifier
                    .windowInsetsPadding(
                        WindowInsets.navigationBars.union(WindowInsets.ime),
                    ),
            ) {
                ChatInputBar(
                    enabled = modelState is ModelState.Loaded,
                    isGenerating = isGenerating,
                    onSend = viewModel::send,
                    onStop = viewModel::stop,
                )
            }
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            if (messages.isEmpty() && modelState !is ModelState.Loading) {
                EmptyState(onLoadModel = { modelPicker.launch(arrayOf("*/*")) })
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(items = messages, key = { it.id }) { message ->
                        ChatBubble(
                            message = message,
                            onToggleThinking = if (message.thinkingContent.isNotEmpty()) {
                                { viewModel.toggleThinkingVisibility(message.id) }
                            } else {
                                null
                            },
                        )
                    }
                }
            }

            if (showScrollToBottom) {
                FloatingActionButton(
                    onClick = {
                        scope.launch {
                            if (messages.isNotEmpty()) {
                                listState.animateScrollToItem(messages.lastIndex)
                            }
                        }
                    },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 16.dp, bottom = 16.dp),
                ) {
                    Icon(
                        Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Ir para o final",
                    )
                }
            }

            if (importState is ImportState.Importing) {
                ImportingDialog(fileName = (importState as ImportState.Importing).fileName)
            }
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text(stringResource(R.string.clear_chat)) },
            text = { Text("Apagar todo o historico da conversa?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showClearConfirm = false
                        viewModel.clearChat()
                    },
                ) {
                    Text("Apagar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text("Cancelar") }
            },
        )
    }
}
