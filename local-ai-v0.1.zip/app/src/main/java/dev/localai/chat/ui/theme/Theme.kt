package dev.localai.chat.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColors = darkColorScheme(
    primary = Emerald80,
    onPrimary = Emerald10,
    primaryContainer = Emerald30,
    onPrimaryContainer = Emerald90,
    secondary = Ink90,
    onSecondary = Slate10,
    background = Slate10,
    onBackground = Ink90,
    surface = Slate20,
    onSurface = Ink90,
    surfaceVariant = Ink30,
    onSurfaceVariant = Ink90,
)

private val LightColors = lightColorScheme(
    primary = Emerald30,
    onPrimary = Emerald90,
    primaryContainer = Emerald90,
    onPrimaryContainer = Emerald10,
    background = Slate95,
    onBackground = Slate10,
    surface = Slate95,
    onSurface = Slate10,
    surfaceVariant = Ink90,
    onSurfaceVariant = Slate10,
)

@Composable
fun LocalAITheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content,
    )
}
