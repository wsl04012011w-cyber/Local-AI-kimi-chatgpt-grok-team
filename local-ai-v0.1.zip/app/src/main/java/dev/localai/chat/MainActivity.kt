package dev.localai.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import dagger.hilt.android.AndroidEntryPoint
import dev.localai.chat.ui.chat.ChatScreen
import dev.localai.chat.ui.theme.LocalAITheme

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Garante que o conteúdo pode ser desenhado atrás das system bars
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            LocalAITheme {
                ChatScreen()
            }
        }
    }
}
